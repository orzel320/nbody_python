import json
import sys
import numpy as np
from vispy import app, scene
from nbody_sim.api import Simulation, ureg

def load_scenario(filepath):
    """Reads a JSON file and configures the 3D simulation and visual styling."""
    with open(filepath, 'r') as f:
        data = json.load(f)
        
    sim = Simulation()
    dt = data.get("dt", 0.01)
    
    sizes = []
    colours = []
    
    # Ensure random generation is reproducible based on the scenario
    np.random.seed(42)
    
    for item in data["bodies"]:
        obj_type = item.get("type", "single")
        
        if obj_type == "single":
            # Wrap single values in a list so NumPy sees them as 1D arrays for concatenation
            mass = [item["mass"]] * ureg(item["mass_unit"])
            pos = [item["position"]] * ureg(item["pos_unit"])
            vel = [item["velocity"]] * ureg(item["vel_unit"])
            
            sim.add_bodies(pos, vel, mass)
            sizes.append(item.get("size", 2.0))
            colours.append(item.get("colour", [1.0, 1.0, 1.0, 1.0]))
            
        elif obj_type == "ring":
            # PROCEDURAL 3D ASTEROID BELT GENERATOR
            count = item["count"]
            
            # 1. Normal Distribution for Radii
            radii = np.random.normal(
                loc=item["radius_mean"], 
                scale=item.get("radius_std", 0.0), 
                size=count
            )
            if "radius_min" in item and "radius_max" in item:
                radii = np.clip(radii, item["radius_min"], item["radius_max"])
                
            angles = np.random.uniform(0, 2 * np.pi, count)
            
            # --- POSITIONS (3D) ---
            pos_x = radii * np.cos(angles)
            pos_y = radii * np.sin(angles)
            z_spread = item.get("pos_z_std", 0.0)
            pos_z = np.random.normal(0.0, z_spread, count) 
            pos = np.column_stack((pos_x, pos_y, pos_z)) * ureg("astronomical_unit")
            
            # --- VELOCITIES (3D) ---
            central_mass = item.get("central_mass", 1.0)
            base_speeds = np.sqrt(central_mass / radii)
            
            speed_var = np.random.normal(1.0, item.get("speed_variance_std", 0.0), count)
            speeds = base_speeds * speed_var
            
            vel_x = -speeds * np.sin(angles)
            vel_y = speeds * np.cos(angles)
            vz_spread = item.get("vel_z_std", 0.0)
            vel_z = np.random.normal(0.0, vz_spread, count) 
            vel = np.column_stack((vel_x, vel_y, vel_z)) * ureg("astronomical_unit / nbody_time")
            
            # --- MASS DISTRIBUTION ---
            mass_mean = item.get("mass_mean", 1e-5)
            mass_std = item.get("mass_std", 0.0)
            raw_masses = np.random.normal(loc=mass_mean, scale=mass_std, size=count)
            raw_masses = np.maximum(raw_masses, 1e-10) # Prevent zero or negative mass
            mass = raw_masses * ureg(item.get("mass_unit", "earth_mass"))
            
            sim.add_bodies(pos, vel, mass)
            
            sizes.extend([item.get("size", 2.0)] * count)
            colours.extend([item.get("colour", [0.7, 0.7, 0.7, 0.4])] * count)
        
    sizes = np.array(sizes, dtype=np.float32)
    colours = np.array(colours, dtype=np.float32)
    
    return sim, dt, sizes, colours, data.get("name", "Simulation")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python viewer.py <path_to_json>")
        sys.exit(1)
        
    filepath = sys.argv[1]
    sim, dt, sizes, colours, name = load_scenario(filepath)
    
    # ==========================================
    # SET UP VISPY 3D CANVAS
    # ==========================================
    canvas = scene.SceneCanvas(keys='interactive', show=True, title=name, bgcolor='black', size=(900, 900))
    view = canvas.central_widget.add_view()
    
    # 3D Turntable camera for orbiting the scene
    view.camera = scene.TurntableCamera(elevation=30, azimuth=45, distance=15.0)
    
    # spherical=True for 3D shading, scaling=True for perspective depth
    markers = scene.visuals.Markers(parent=view.scene, spherical=True, scaling=True)
    
    # Scale sizes from AU to reasonable visual proportions
    SCENE_SIZE_FACTOR = 0.02
    scaled_sizes = sizes * SCENE_SIZE_FACTOR
    
    # Set up 3D lighting (VisPy internal API requires American spelling here)
    markers.light_position = (10, 10, 10)
    markers.light_ambient = 0.3 
    markers.light_color = 'white'
    
    # ==========================================
    # THE REAL-TIME UPDATE LOOP
    # ==========================================
    def update(ev):
        sim.step(dt * ureg.nbody_time)
        markers.set_data(
            pos=sim._positions.astype(np.float32), 
            face_color=colours, 
            size=scaled_sizes, 
            edge_width=0,
            edge_color='transparent' 
        )

    timer = app.Timer(interval='auto', connect=update, start=True)
    print(f"Loaded scenario: {name}. Running...")
    app.run()