import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from .api import ureg

def create_perspective_animation(sim, dt, sizes, colours, steps=300, camera_z=15.0, fov=15.0):
    """
    Steps the simulation and renders a 3D perspective projection using Matplotlib.
    Returns a FuncAnimation object ready for Jupyter/Colab display or MP4 export.
    """
    fig, ax = plt.subplots(figsize=(8, 8), facecolor='black', dpi=120)
    fig.subplots_adjust(left=0, bottom=0, right=1, top=1) # Remove all margins
    
    ax.set_facecolor('black')
    ax.set_xlim(-10, 10)
    ax.set_ylim(-10, 10)
    ax.axis('off') # Hide the grid and axes
    
    # Initialize the scatter plot
    scatter = ax.scatter([], [], c=[], s=[], edgecolors='none')
    
    def update(frame):
        sim.step(dt * ureg.nbody_time)
        
        x = sim._positions[:, 0]
        y = sim._positions[:, 1]
        z = sim._positions[:, 2]
        
        # 1. Calculate camera depth
        # If camera is at z=15, and object is at z=2, depth is 13.
        depth = camera_z - z
        
        # Prevent division by zero if an object flies behind the camera
        depth = np.maximum(depth, 0.1) 
        
        # 2. Perspective Projection (X and Y)
        scale_factor = fov / depth
        proj_x = x * scale_factor
        proj_y = y * scale_factor
        
        # 3. Perspective Projection (Size)
        # Matplotlib 's' parameter is area, so we square the scale factor
        # We multiply by a baseline multiplier (e.g., 20.0) so they aren't microscopic
        proj_sizes = sizes * (scale_factor ** 2) * 20.0
        
        # 4. Z-Buffer Sorting (Painter's Algorithm)
        # We must draw the furthest objects (lowest Z) first, so they appear in the background
        sort_indices = np.argsort(z)
        
        # Update the scatter plot with sorted data
        scatter.set_offsets(np.column_stack((proj_x[sort_indices], proj_y[sort_indices])))
        scatter.set_sizes(proj_sizes[sort_indices])
        scatter.set_facecolors(colours[sort_indices])
        
        return scatter,

    # Create the animation object
    anim = FuncAnimation(fig, update, frames=steps, interval=33, blit=True)
    
    # We must close the figure so it doesn't accidentally print a static frame in the notebook
    plt.close(fig) 
    
    return anim