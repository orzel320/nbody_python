import numpy as np
import pint
import math

ureg = pint.UnitRegistry()
ureg.define(f"nbody_time = 1 * year / {2 * math.pi}")
ureg.define("solar_mass = 1.98847e30 * kilogram")
ureg.define("earth_mass = 5.9722e24 * kilogram")

class Simulation:
    def __init__(self):
        """Initialises an empty N-body simulation."""
        self._positions = np.empty((0, 3), dtype=np.float64)
        self._velocities = np.empty((0, 3), dtype=np.float64)
        self._masses = np.empty(0, dtype=np.float64)

    def add_bodies(self, positions, velocities, masses):
        """
        Add bodies to the simulation. Accepts Pint quantities, 
        converts them to base SI units, and strips them for Numba.
        """
        if not isinstance(positions, pint.Quantity):
            positions = positions * ureg.meter
        if not isinstance(velocities, pint.Quantity):
            velocities = velocities * (ureg.meter / ureg.second)
        if not isinstance(masses, pint.Quantity):
            masses = masses * ureg.kilogram

        positions = positions.to(ureg.astronomical_unit)
        velocities = velocities.to(ureg.astronomical_unit / ureg.nbody_time)
        masses = masses.to(ureg.solar_mass)

        raw_positions = np.array(positions.magnitude, dtype=np.float64)
        raw_velocities = np.array(velocities.magnitude, dtype=np.float64)
        raw_masses = np.array(masses.magnitude, dtype=np.float64)

        if self._positions.size == 0:
            self._positions = raw_positions
            self._velocities = raw_velocities
            self._masses = raw_masses
        else:
            self._positions = np.vstack((self._positions, raw_positions))
            self._velocities = np.vstack((self._velocities, raw_velocities))
            self._masses = np.concatenate((self._masses, raw_masses))
            
    def step(self, dt):
        """Advances the simulation by one time step."""
        from .physics import calculate_barnes_hut_accel, update_bodies
        from .quadtree import build_tree
        
        if not isinstance(dt, pint.Quantity):
            dt = dt * ureg.nbody_time
        dt_raw = dt.to(ureg.nbody_time).magnitude

        n = self._positions.shape[0]
        if n == 0:
            return

        # 1. Prepare indices and build the tree
        body_indices = np.arange(n, dtype=np.int32)
        tree, _ = build_tree(self._positions, self._masses, body_indices, leaf_capacity=1)

        # 2. Calculate accelerations using the tree
        # theta_sq = 1.0 is the standard sweet spot between speed and accuracy
        acc = calculate_barnes_hut_accel(
            self._positions, self._masses, tree, body_indices, 
            theta_sq=1.0, epsilon_sq=0.01
        )
        
        # 3. Apply Symplectic Euler integration
        update_bodies(self._positions, self._velocities, acc, dt_raw)