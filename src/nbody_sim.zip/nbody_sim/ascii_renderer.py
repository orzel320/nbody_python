import numpy as np
import time
import sys

# Try to import Jupyter's clear_output. If it fails, we assume standard terminal.
try:
    from IPython.display import clear_output, display
    IN_JUPYTER = True
except ImportError:
    IN_JUPYTER = False

def render_ascii_frame(positions, masses, width=80, height=40, view_radius=10.0):
    """
    Takes 3D positions and returns a string representing a 2D ASCII frame.
    view_radius defines the +/- bounds in Astronomical Units.
    """
    # Create an empty grid of spaces
    grid = np.full((height, width), ' ', dtype=str)
    
    # Extract X and Y for a top-down projection
    x = positions[:, 0]
    y = positions[:, 1]
    
    # Normalize coordinates from physical space to a 0.0 -> 1.0 range
    x_norm = (x + view_radius) / (2 * view_radius)
    y_norm = (y + view_radius) / (2 * view_radius)
    
    # Scale to our text grid dimensions
    grid_x = (x_norm * (width - 1)).astype(int)
    grid_y = (y_norm * (height - 1)).astype(int)
    
    # Filter out bodies that have flown outside our viewing radius
    valid = (grid_x >= 0) & (grid_x < width) & (grid_y >= 0) & (grid_y < height)
    
    gx = grid_x[valid]
    gy = grid_y[valid]
    m = masses[valid]
    
    # Paint the particles onto the grid
    for i in range(len(gx)):
        # Invert Y so positive Y is "up" on the screen
        plot_y = (height - 1) - gy[i]
        plot_x = gx[i]
        
        # Assign different characters based on relative mass
        if m[i] > 10.0:     # Supermassive
            symbol = '@'
        elif m[i] > 0.1:    # Planets
            symbol = 'O'
        elif m[i] > 0.001:  # Moons
            symbol = 'o'
        else:               # Asteroids
            symbol = '.'
            
        grid[plot_y, plot_x] = symbol

    # Join the NumPy array of characters into a single printable string
    frame_str = "\n".join("".join(row) for row in grid)
    
    # Add a nice border
    border = "-" * width
    return f"{border}\n{frame_str}\n{border}"

def animate_in_jupyter(sim, steps=500, dt=0.01, fps=30, view_radius=10.0):
    """Runs the simulation and animates it in a Jupyter Notebook output cell."""
    sleep_time = 1.0 / fps
    
    for step in range(steps):
        sim.step(dt)
        
        # Only draw every 5th frame to keep it fast, or draw all depending on speed
        if step % 2 == 0:
            frame = render_ascii_frame(
                sim._positions, 
                sim._masses, 
                width=80, 
                height=30, 
                view_radius=view_radius
            )
            
            if IN_JUPYTER:
                clear_output(wait=True)
                print(frame)
                time.sleep(sleep_time)
            else:
                # Fallback for standard terminals
                sys.stdout.write("\033[H\033[J") # ANSI escape code to clear screen
                print(frame)
                time.sleep(sleep_time)