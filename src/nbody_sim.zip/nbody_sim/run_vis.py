import numpy as np
from vispy import app, scene
from nbody_sim.api import Simulation, ureg

# ==========================================
# 1. INITIALIZE THE SIMULATION
# ==========================================
sim = Simulation()

CENTRAL_MASS = 100.0

# Central Star
sim.add_bodies(
    positions=[[0.0, 0.0]] * ureg.astronomical_unit,
    velocities=[[0.0, 0.0]] * (ureg.astronomical_unit / ureg.nbody_time),
    masses=[CENTRAL_MASS] * ureg.solar_mass
)

# 2000 Planets (Let's crank it up since we have VisPy!)
np.random.seed(42)
num_planets = 1000
angles = np.random.uniform(0, 2 * np.pi, num_planets)
radii = np.random.uniform(5.0, 40.0, num_planets)

pos_x = radii * np.cos(angles)
pos_y = radii * np.sin(angles)
positions = np.column_stack((pos_x, pos_y)) * ureg.astronomical_unit

speeds = np.sqrt(CENTRAL_MASS / radii)
vel_x = -speeds * np.sin(angles)
vel_y = speeds * np.cos(angles)
velocities = np.column_stack((vel_x, vel_y)) * (ureg.astronomical_unit / ureg.nbody_time)

masses = np.ones(num_planets) * ureg.earth_mass
sim.add_bodies(positions, velocities, masses)

# ==========================================
# 2. EXACT GPU STYLING (Forcing Float32)
# ==========================================
n_total = sim._positions.shape[0]

# 1. Fixed Pixel Sizes
# We explicitly use float32 so the OpenGL shader understands it
dynamic_sizes = np.full(n_total, 2.5, dtype=np.float32)  # Planets are tiny (2.5 pixels)
dynamic_sizes[0] = 20.0                                  # The central star is 20 pixels

# 2. RGBA Colors (Red, Green, Blue, Alpha transparency)
# Give planets a slight icy-blue tint and 60% transparency 
colors = np.full((n_total, 4), [0.6, 0.8, 1.0, 0.6], dtype=np.float32)
# Make the central star pure white and fully opaque (100% alpha)
colors[0] = [1.0, 1.0, 1.0, 1.0]

# ==========================================
# 3. SET UP VISPY CANVAS
# ==========================================
canvas = scene.SceneCanvas(keys='interactive', show=True, bgcolor='black', size=(800, 800))
view = canvas.central_widget.add_view()

view.camera = scene.PanZoomCamera(aspect=1)
view.camera.set_range(x=(-40, 40), y=(-40, 40)) # Zoom out a bit more by default

markers = scene.visuals.Markers(parent=view.scene)

# ==========================================
# 4. THE REAL-TIME UPDATE LOOP
# ==========================================
def update(ev):
    sim.step(0.01 * ureg.nbody_time)
    
    # Cast positions to float32 right before sending to the GPU
    # Explicitly set edge_color to transparent to kill the black outlines
    markers.set_data(
        pos=sim._positions.astype(np.float32), 
        face_color=colors, 
        size=dynamic_sizes, 
        edge_width=0,
        edge_color='transparent' 
    )

timer = app.Timer(interval='auto', connect=update, start=True)

if __name__ == '__main__':
    print("Simulation running! Use Right-Click + Drag to zoom, and Left-Click to pan.")
    app.run()