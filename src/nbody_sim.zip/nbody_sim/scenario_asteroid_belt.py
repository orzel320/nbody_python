import numpy as np
from nbody_sim.api import Simulation, ureg
from nbody_sim import Visualiser

sim = Simulation()

# 1. Add Sun, Mars, Jupiter
sim.add_bodies(
    positions=[[0.0, 0.0]] * ureg.astronomical_unit,
    velocities=[[0.0, 0.0]] * (ureg.astronomical_unit / ureg.nbody_time),
    masses=[1.0] * ureg.solar_mass
)
sim.add_bodies(
    positions=[[1.52, 0.0]] * ureg.astronomical_unit,
    velocities=[[0.0, np.sqrt(1.0 / 1.52)]] * (ureg.astronomical_unit / ureg.nbody_time),
    masses=[0.107] * ureg.earth_mass
)
sim.add_bodies(
    positions=[[5.20, 0.0]] * ureg.astronomical_unit,
    velocities=[[0.0, np.sqrt(1.0 / 5.20)]] * (ureg.astronomical_unit / ureg.nbody_time),
    masses=[317.8] * ureg.earth_mass
)

# 2. Add Asteroid Belt (With Eccentricity)
num_asteroids = 3000
radii = np.clip(np.random.normal(2.7, 0.3, num_asteroids), 2.1, 3.3)
angles = np.random.uniform(0, 2 * np.pi, num_asteroids)

pos_x = radii * np.cos(angles)
pos_y = radii * np.sin(angles)
positions = np.column_stack((pos_x, pos_y)) * ureg.astronomical_unit

base_speeds = np.sqrt(1.0 / radii)
speeds = base_speeds * np.random.normal(1.0, 0.05, num_asteroids)
radial_vel = np.random.normal(0.0, 0.03, num_asteroids)

vel_x = -speeds * np.sin(angles) + radial_vel * np.cos(angles)
vel_y = speeds * np.cos(angles) + radial_vel * np.sin(angles)
velocities = np.column_stack((vel_x, vel_y)) * (ureg.astronomical_unit / ureg.nbody_time)

sim.add_bodies(positions, velocities, np.ones(num_asteroids) * 1e-5 * ureg.earth_mass)

# 3. Styling
n_total = sim._positions.shape[0]
sizes = np.full(n_total, 2.0, dtype=np.float32)
colors = np.full((n_total, 4), [0.7, 0.7, 0.7, 0.4], dtype=np.float32) 

# Sun, Mars, Jupiter overrides
sizes[0:3] = [25.0, 6.0, 15.0]
colors[0] = [1.0, 0.9, 0.5, 1.0] 
colors[1] = [1.0, 0.3, 0.1, 1.0] 
colors[2] = [0.8, 0.6, 0.4, 1.0] 

# 4. RUN!
vis = Visualiser(sim, dt=0.005, sizes=sizes, colors=colors, camera_range=(-6, 6))
vis.run()